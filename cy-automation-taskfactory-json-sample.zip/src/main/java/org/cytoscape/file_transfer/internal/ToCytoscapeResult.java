package org.cytoscape.file_transfer.internal;


public class ToCytoscapeResult {
	public String filename;
	
	public ToCytoscapeResult(){}
	
	public ToCytoscapeResult(String filename) {
		this.filename = filename;
	}
}
